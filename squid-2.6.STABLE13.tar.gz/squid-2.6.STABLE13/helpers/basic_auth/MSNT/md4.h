/* md4.c */
void mdfour(unsigned char *out, unsigned char *in, int n);
