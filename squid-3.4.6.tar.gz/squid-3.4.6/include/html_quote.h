#ifndef _SQUID_HTML_QUOTE_H
#define _SQUID_HTML_QUOTE_H

#ifdef __cplusplus
extern "C"
#else
extern
#endif

char *html_quote(const char *);

#endif /* _SQUID_HTML_QUOTE_H */
