#ifndef _INC_XUSLEEP_H
#define _INC_XUSLEEP_H

SQUIDCEXTERN int xusleep(unsigned int);

#endif /* _INC_XUSLEEP_H */
