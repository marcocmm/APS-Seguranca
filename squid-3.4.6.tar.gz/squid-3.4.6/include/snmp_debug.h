#ifndef SQUID_SNMP_DEBUG_H
#define SQUID_SNMP_DEBUG_H

SQUIDCEXTERN void snmplib_debug(int, const char *,...) PRINTF_FORMAT_ARG2;

#endif /* SQUID_SNMP_DEBUG_H */
