/*
 * Auto-Generated File. Changes will be destroyed.
 */
#include "squid.h"
#include "swap_log_op.h"

const char *swap_log_op_str[] = {
	"SWAP_LOG_NOP",
	"SWAP_LOG_ADD",
	"SWAP_LOG_DEL",
	"SWAP_LOG_VERSION",
	"SWAP_LOG_MAX"
};
