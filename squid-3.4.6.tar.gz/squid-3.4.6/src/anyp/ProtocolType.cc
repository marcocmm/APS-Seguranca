/*
 * Auto-Generated File. Changes will be destroyed.
 */
#include "squid.h"
#include "anyp/ProtocolType.h"
namespace AnyP
{

const char *ProtocolType_str[] = {
	"NONE",
	"HTTP",
	"FTP",
	"HTTPS",
	"COAP",
	"COAPS",
	"GOPHER",
	"WAIS",
	"CACHE_OBJECT",
	"ICP",
#if USE_HTCP
	"HTCP",
#endif
	"URN",
	"WHOIS",
	"INTERNAL",
	"ICY",
	"UNKNOWN",
	"MAX"
};
}; // namespace AnyP
