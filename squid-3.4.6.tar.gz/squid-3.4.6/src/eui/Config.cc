#include "squid.h"
#include "eui/Config.h"

Eui::EuiConfig Eui::TheConfig;
